
- GPT: used gpt in order to make sure i got all the cubs correct and where I wanted. used it help me with animation as well
- GPT: used it help with the mouse click becuase i was having a lot of trouble there

- GPT: used to help me make the realistic dirt house
- helped make the trees